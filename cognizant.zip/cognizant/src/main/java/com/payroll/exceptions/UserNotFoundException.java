package com.payroll.exceptions;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
