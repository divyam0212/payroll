package com.payroll.exceptions;

public class PayrollException extends Exception{

	public PayrollException(String message)
	{
		super(message);
	}

}
