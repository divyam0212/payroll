package com.payroll.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.payroll.model.Address;
import com.payroll.model.Department;

@Service
public class DepartmentRepoService {

	public DepartmentRepoService() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	public DepartmentRespository departmentRespository;

	public List<Department> getAllDept(){
		
		return departmentRespository.findAll();
	}
	public void deleteDepartment(int deptId){
		departmentRespository.deleteById(deptId);	
	}
	
	public void saveDept(Department department){
		departmentRespository.save(department);
	}
}
