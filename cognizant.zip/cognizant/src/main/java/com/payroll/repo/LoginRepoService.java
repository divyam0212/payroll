package com.payroll.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginRepoService {

	public LoginRepoService() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	LoginRepository loginRepository;
	
	
public int validateUser(String username,String password){

	//return loginRepository.fetchUserByNameAndPassword(username, password);
	return 0;
}
	
	
}
