package com.payroll.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.payroll.model.Skills;
@Repository
public interface SkillRespository extends JpaRepository<Skills, Integer> {

}
