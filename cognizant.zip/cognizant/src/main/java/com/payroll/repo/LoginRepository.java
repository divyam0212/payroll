package com.payroll.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.payroll.model.LoginDetails;
import com.payroll.model.Skills;

@Repository
public interface LoginRepository  extends JpaRepository<LoginDetails, String>  {

	
//public int fetchUserByNameAndPassword( String username, String password);
	

}
