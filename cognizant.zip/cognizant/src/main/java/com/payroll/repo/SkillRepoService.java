package com.payroll.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.payroll.model.Address;
import com.payroll.model.Employee;
import com.payroll.model.Skills;

@Service
public class SkillRepoService {

	public SkillRepoService() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	SkillRespository skillRespository;

	public List<Skills> getAllSkills() {

		return skillRespository.findAll();

	}

	public void saveSkills(Skills skills) {
		skillRespository.save(skills);
		
	}
	public void deleteSkill(int skillId){
		skillRespository.deleteById(skillId);	
	}
	
}
