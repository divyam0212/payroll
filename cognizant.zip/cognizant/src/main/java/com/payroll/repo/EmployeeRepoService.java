package com.payroll.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payroll.model.Employee;

@Service
public class EmployeeRepoService {

	public EmployeeRepoService() {
		// TODO Auto-generated constructor stub
	}


	@Autowired(required=true)
	EmployeeRepository employeeRepository;
	
	public int saveEmp(Employee employee){
    int flag=0;
		Employee e=  employeeRepository.save(employee);
		if(e!=null){
			flag=1;
			
		}else{
		
		}
		
		return flag;
	}
	
	public List<Employee> findAllEmployee(){
		return employeeRepository.findAll();
	}
	
	public void deleteEmployee(int empId){
		employeeRepository.deleteById(empId);
	}
}
