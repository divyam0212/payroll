package com.payroll.repo;

import java.util.List;

import org.jvnet.hk2.annotations.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.payroll.model.Address;
import com.payroll.model.Employee;

@Service
public class AddressRepoService {

	public AddressRepoService() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired(required=true)
	AddressRepository addressRepository;
	
	public List<Address> findAllAddress(){
		return addressRepository.findAll();
	}
	public void deleteAddress(int addressId){
		addressRepository.deleteById(addressId);
	}
	public void saveAddress(Address address){
		addressRepository.save(address);
	}
}
