package com.payroll.repo;

import java.util.List;

import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.payroll.model.Employee;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	
//List<Employee>	fetchAllEmployeeDetails();
//Employee fetchEmployeeDetails( int empId);

}
