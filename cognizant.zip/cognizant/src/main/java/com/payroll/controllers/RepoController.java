package com.payroll.controllers;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.ResponseTransfer;
import com.payroll.model.Skills;
import com.payroll.repo.AddressRepoService;
import com.payroll.repo.DepartmentRepoService;
import com.payroll.repo.EmployeeRepoService;
import com.payroll.repo.SkillRepoService;

@RestController
@CrossOrigin
public class RepoController {
	public RepoController() {
		// TODO Auto-generated constructor stub
	}

	@Autowired(required=true)
	AddressRepoService addressRepoService;
	
	@Autowired(required=true)
	DepartmentRepoService departmentRepoService;
	
	@Autowired(required=true)
	EmployeeRepoService employeeRepoService;
	
	@Autowired(required=true)
	SkillRepoService skillRepoService;
	
	@GetMapping("/alldept")
	public List<Department> getAllDepartment(){
		return departmentRepoService.getAllDept();
	}
	
	@GetMapping("/alladdress")
	public List<Address> findAllAddress()
	{
		return addressRepoService.findAllAddress();
	}

	@GetMapping("/allemployee")
	public List<Employee> findAllEmployee(){
		return employeeRepoService.findAllEmployee();
	}
	
	@GetMapping("/allskills")
	public List<Skills> getAllSkills(){
		return skillRepoService.getAllSkills();
	}
	// POST MAPPING
	
	@PostMapping("/saveemp")
	public String saveEmp(@RequestBody Employee employee){
		employeeRepoService.saveEmp(employee);
		return "successfully registered";
		
	}
	@PostMapping("/savedept")
	public String saveDept(@RequestBody Department department){
		departmentRepoService.saveDept(department);
		return "Successfully saved or updated";
	}
	@PostMapping("/saveaddr")
	public String saveAddress(@RequestBody Address address){
		addressRepoService.saveAddress(address);
		return "Successfully saved or updated";
	}
	@PostMapping("/saveskill")
	public String saveSkills(@RequestBody Skills skills){
		skillRepoService.saveSkills(skills);
		return "Successfully saved or updated";
	}
	// DELETE MAPPING
	
	@DeleteMapping("/deleteemp/{empId}")
	public void deleteEmployee(@PathVariable int empId){
		employeeRepoService.deleteEmployee(empId);	
	}
	@DeleteMapping("/deleteaddress/{addressId}")
	public void deleteAddress(@PathVariable int addressId){
		addressRepoService.deleteAddress(addressId);	
	}
	@DeleteMapping("/deleteskill/{skillId}")
	public void deleteSkill(@PathVariable int skillId){
		skillRepoService.deleteSkill(skillId);	
	}
	@DeleteMapping("/deletedept/{deptId}")
	public void deleteDepartment(@PathVariable int deptId){
		departmentRepoService.deleteDepartment(deptId);	
	}
}
