package com.payroll.app;

import java.util.List;

import javax.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import com.payroll.controllers.RepoController;
import com.payroll.controllers.TestController;
import com.payroll.model.Department;
import com.payroll.repo.AddressRepoService;
import com.payroll.repo.DepartmentRepoService;
import com.payroll.repo.EmployeeRepoService;
import com.payroll.repo.SkillRepoService;
import com.payroll.rest.EmployeeRestController;
import com.payroll.services.DepartmentService;
import com.payroll.services.EmployeeService;
import com.payroll.services.LoginService;
import com.payroll.services.SkillsService;

/*@Configuration
@ComponentScan({"com.payroll"})
@EnableWebMvc
@EnableAutoConfiguration*/


@EntityScan("com.payroll.*")
@EnableJpaRepositories(value="com.payroll.repo")
@SpringBootApplication

public class App extends SpringBootServletInitializer {

	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		// TODO Auto-generated method stub
		return builder.sources(App.class);
	}
	
	@Bean
	public AddressRepoService addressRepoService(){
		return new AddressRepoService();
	}
	
	@Bean
	public DepartmentRepoService departmentRepoService(){
		return new DepartmentRepoService();
	}
	
	@Bean
	public EmployeeRepoService employeeRepoService(){
		return new EmployeeRepoService();
	}
	
	@Bean
	public SkillRepoService skillRepoService(){
		return new SkillRepoService();
	}
	@Bean 
	public RepoController repoController(){
		return new RepoController();
	}
	
	/*@Bean
	public EmployeeRestController employeeRestController(){
		return new EmployeeRestController();
	}
	
	@Bean
	public TestController testController(){
		return new TestController();
	}
	
	@Bean
	public EmployeeService employeeService(){
		return new EmployeeService();
	}
	@Bean
	public DepartmentService departmentService(){
		return new DepartmentService();
	}
	@Bean
	public SkillsService skillsService(){
		return new SkillsService();
	}
	@Bean
	public LoginService loginService(){
		return new LoginService();
	}*/
	@Bean
	public UrlBasedViewResolver setUpViewResolver(){
		UrlBasedViewResolver resolver=new UrlBasedViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		resolver.setViewClass(JstlView.class);
		
		return resolver;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SpringApplication.run(App.class, args);
	}

}
